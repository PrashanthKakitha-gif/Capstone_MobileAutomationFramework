package TestFunctions;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.remote.DesiredCapabilities;

import ResuableMethods.PageUtility;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.testng.annotations.Test;

public class BaseTest {
	
	public static AppiumDriver driver;
	PageUtility util = new PageUtility();
	
	String Application = util.readProperty("Application");

//	public LoginSteps() {
//		System.out.println("Initializing LoginSteps...");
//		this.driver = Hooks.getDriver();
//		if (driver == null) {
//			System.out.println("Driver is null in LoginSteps constructor!");
//			throw new RuntimeException("Driver is not initialized.");
//		}
//		this.homePage = new HomePage(driver);
//		this.loginPage = new LoginPage(driver);
//	}

	public void setup() {
		
		DesiredCapabilities caps = new DesiredCapabilities();
		if(Application.equalsIgnoreCase("MB_Android_App")) {
			caps.setCapability("appium:deviceName", util.readProperty("Device_Name"));
			caps.setCapability("appium:platformName", util.readProperty("Platform"));
			caps.setCapability("appium:platformVersion", util.readProperty("Platform_Version"));
			caps.setCapability("appium:app", util.readProperty("App"));
			caps.setCapability("appium:automationName", util.readProperty("Automation_Name"));
			caps.setCapability("noReset", true);
			caps.setCapability("autoGrantPermissions", true);
//			caps.setCapability("appium:appPackage", util.readProperty("AppPackage"));
		}else if(Application.equalsIgnoreCase("MB_IOS_App")) {
			
		}else if(Application.equalsIgnoreCase("Mobile_Browser")) {
			caps.setCapability("appium:deviceName", util.readProperty("Mobile_Web_Device_Name"));
			caps.setCapability("appium:platformName", util.readProperty("Mobile_Web_Platform"));
			caps.setCapability("appium:platformVersion", util.readProperty("Mobile_Web_Platform_Version"));
			caps.setCapability("appium:browserName", util.readProperty("Mobile_Web_browserName"));
			caps.setCapability("appium:chromedriverExecutable", util.readProperty("Mobile_Web_Executable"));
			caps.setCapability("appium:automationName", util.readProperty("Mobile_Web_Automation_Name"));
			caps.setCapability("noReset", true);
			caps.setCapability("autoGrantPermissions", true);
		}
		
		try {
			if(Application.equalsIgnoreCase("Mobile_Browser")) {
				driver = new AppiumDriver<>(new URL(util.readProperty("Appium_Url")), caps);
				driver.get(util.readProperty("Mobile_Web_Url"));
				System.out.println("Driver Initialized Successfully : " + Application);
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			}else {
				driver = new AppiumDriver<>(new URL(util.readProperty("Appium_Url")), caps);
				System.out.println("Driver Initialized Successfully : " + Application);
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			}
			
		}catch (Exception e) {
			System.out.println("Failed to Initialized Driver. Please check Appium url");
			e.printStackTrace();
		}

	}


	public void tearDown() throws IOException {
		System.out.println("Tearing down Appium driver...");
		if (driver != null) {
			driver.quit();
			driver = null; // Ensure driver is reset between tests
			System.out.println("Appium driver quit successfully.");
		}

		String command = "cmd /c start cmd.exe /K \" COLOR 30 && cd \"C:\\Users\\vivekak\\Downloads\\BrowserMobileAutomationTesting && allure serve allure-results";
		//        String command = "cmd /c start cmd.exe /K \" COLOR 30 && cd \"C:\\Users\\vivekak\\Downloads\\Combined_ANBTestNG_FrameWork\\target && allure serve allure-results";
		Process chiledprocess = Runtime.getRuntime().exec(command);


		String command1 = "cmd /c start cmd.exe /K \" COLOR 30 && cd \"C:\\Users\\vivekak\\Downloads\\BrowserMobileAutomationTesting && rmdir /s /q allure-report && allure generate --single-file allure-results";
		//        String command1 = "cmd /c start cmd.exe /K \" COLOR 30 && cd \"C:\\Users\\vivekak\\Downloads\\Combined_ANBTestNG_FrameWork\\target && rmdir /s /q allure-report && allure generate --single-file allure-results";
		Process chiledprocess1 = Runtime.getRuntime().exec(command1);

	}

//	public static AppiumDriver getDriver() {
//		System.out.println("Returning Appium driver instance...");
//		return driver;
//	}



}
